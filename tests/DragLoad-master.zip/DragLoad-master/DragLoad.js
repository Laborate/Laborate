


DragLoad = {}; // = DragLoad.

DragLoad.start = function(ev){ // attach .dragging  &  UID
//	console.log('dragging',ev,ev.target);
//    var uid = $(ev.target).attr('uid');
    $(ev.target).addClass('dragging');
    $('.isDropTarget').addClass('waiting');
//    ev.dataTransfer.setData("Text",uid);
	DragLoad.currentElement = $(ev.target);
}

DragLoad.stop = function(ev){ // remove .dragging
    $(ev.target).removeClass('dragging');
    $('.isDropTarget').removeClass('waiting');
}


DragLoad.over = function(ev){ // gotta be there for some reason
//    var tmp = $(ev.target);
//    console.log('dd-OVER',tmp[0]);
//    ev.preventDefault(); 
//    ev.stopPropagation();
    ev.originalEvent.preventDefault(); 
}

DragLoad.enter = function(ev){ // attach .draggable
    $('.dragOver').removeClass('dragOver');
    var tmp = $(ev.target);
//    console.log('dd-enter',tmp[0]);
//    if(!tmp.hasClass('isDropTarget')) { return; }
    if(!tmp.hasClass('isDropTarget')) { tmp = tmp.parents('.isDropTarget').first(); }
//    console.log('   new-enter',tmp[0]);
    setTimeout(function(){
	    tmp.addClass('dragOver');
    },10);
//    ev.preventDefault(); 
    ev.originalEvent.preventDefault();
}

DragLoad.leave = function(ev){ // remove .draggable
    var tmp = $(ev.target);
//    console.log('dd-leave',tmp[0]);
//    if(!tmp.hasClass('isDropTarget')) { return; }
    if(!tmp.hasClass('isDropTarget')) { tmp = tmp.parents('.isDropTarget').first(); }
//    console.log('   new-leave',tmp[0]);
    tmp.removeClass('dragOver');
//    ev.preventDefault(); 
    ev.originalEvent.preventDefault();
}







// on DROP
// distinquish between dropped DOM-elements & Files
DragLoad.drop = function (ev){ 
    $(ev.target).removeClass('dragOver');
    ev.originalEvent.preventDefault();
    ev.originalEvent.stopPropagation();
    var target = $(ev.target); // dropped here
    if(!target.hasClass('isDropTarget')){ target = target.parents('.isDropTarget').first(); }
    var dt = ev.originalEvent.dataTransfer;
	console.log('dropped',dt,target[0]);
    if(dt.files.length){  // File - Drop
        var fs = new FileScanner(ev.originalEvent.dataTransfer);
        fs.onDone = function(files){ 
        	if(target.attr('onFileDrop')){
	        	eval(target.attr('onFileDrop'))(files, target); 
            }
            if(target.attr('uploadController')){
            	new FileListHandle(files, target);
            }
        };
//        console.log(fs);
    } else { // DOM - Drop
    	console.log('dom-drop');
        eval(target.attr('onDomDrop'))(DragLoad.currentElement, target);
//        var id = dt.getData("Text");
//        var domItem = $('[uid='+id+']'); // dragged item
//        eval(target.attr('onDomDrop'))(domItem, target);
    }
}





 
// reads the dropped files AND/OR sub-folders into a queue
// when done a custom .onDone - function is executed
FileScanner = function(dataTransfer){ 
	this.queue = [];  // folder & file-reads are async
    this.total = 0;
    this.lastTotal = 0;
    
    this.addFile = function(entry,merge){
    	this.total++;
        entry.file( function(f){ 
            $.extend(f,merge);
//            f.sizeString = this.getSizeString(f);
            this.queue.push(f);
			this.checkDone();
        }.bind(this) );
    }
    this.readFiles = function(dataTransfer){
        if($.browser.webkit){
            // webkit
            files = dataTransfer.items;
            for (var i=0; i<files.length; i++) {
                var entry = files[i].webkitGetAsEntry();
                if(entry.isFile){
                    this.addFile(entry);
                } else {
                    this.subFolders( entry );
                }
            }   
        } else {
            // MOZ no support for directory upload
            // https://developer.mozilla.org/en-US/docs/DOM/FileList
            files = dataTransfer.files; 
            for (var i=0; i<files.length; i++) {
                this.queue.push(files[i]);
            }  
        }
    }
    
    this.subFolders = function(folder){
        var dirReader = folder.createReader();
        dirReader.readEntries( function(entries) {
            for (var i=0; i<entries.length; i++) {
    //            console.log('entry',entries[i]);
                var entry = entries[i];
                if(entry.isFile){
                	var path = entry.fullPath.substr(0,entry.fullPath.length-entry.name.length);
                	console.log('ENTRY',entry,path,-entry.name.length);
                    this.addFile(entry,{path:path});
                } else {
                    this.subFolders( entry );
                }
            }
        }.bind(this) );
    }
    
    this.checkDone = function(){
//    	console.log('here now',this);
    	if(!this.total){ this.lastTotal = this.total; return; }
        if(this.queue.length != this.total){ this.lastTotal = this.total; return; }
//        if(this.lastTotal != this.total){ return; }
        console.log('FileScanner DONE',this.queue.length); 
        if(this.onDone){ this.onDone(this.queue); }
    }
    
    
    
    this.readFiles(dataTransfer); // start working 
}





FileListHandle = function(fileList, dropTarget){
    this.fileList = fileList;
    this.current = 0;
    this.dropTarget = dropTarget;
    this.uploadTarget = $(dropTarget).attr('uploadTarget');
    if(!$(dropTarget).attr('uploadController')) { console.log("no fileController"); return; }
    this.controller = eval($(dropTarget).attr('uploadController'));
        
    this.getSizeString = function(file){
        if(file.size/1024/1024>=1){ return Math.round(file.size/1024/1024)+' MB'; }
        if(file.size/1024>=1){ return Math.round(file.size/1024)+' KB'; }
    }
    this.start = function(){
    	if(this.current > this.fileList.length-1){
        	console.log('nothing left to upload');
            return;
        }
        this.file = this.fileList[this.current];
        this.file.total = {count:this.fileList.length};
        this.file.total.current = this.current+1;
        this.file.total.percent = Math.round(this.file.total.current*100/this.file.total.count);
        this.file.sizeString = this.getSizeString(this.file);
        this.controller.start(this.file);
        if(this.uploadTarget){
        	this.file.xhr = FileUpload(this.file, this.uploadTarget, this);
        } else {
            this.next();
        }
    }
    this.next = function(){
        this.current++;
        this.start();
    }
    this.complete = function(evt) {
    	this.file.response = this.responseText;
		try{ this.controller.complete(this.file); } catch(e){}
        this.next();
    }
    this.progress = function(evt) { 
        if (!evt.lengthComputable) { return; }
        this.file.percent = Math.round(evt.loaded * 100 / evt.total);
//    	console.log('progress on:',this.file,evt.percent);
    	try{ this.controller.progress(this.file); } catch(e){}
    }
    this.failed = function(evt) { 
    	this.controller.failed(this.file); 
        this.next();
    }
    this.canceled = function(evt) { 
    	this.controller.canceled(this.file); 
        this.next();
    }
    
    this.start();
}





FileUpload = function(file, target, handler, options ){ // upload a file
//	console.log('upload',file,target,handler);
    if(!options){ options = []; }
    var fd = new FormData();
    $.each(options, function(k,v){
        fd.append(k,v);
    });
    fd.append('file',file);
    fd.append('sourceFolder',file.path);
//	console.log('upload',fd);
    
    var xhr = new XMLHttpRequest();
    xhr.upload.addEventListener("progress", handler.progress.bind(handler), false);
    xhr.addEventListener("load", handler.complete.bind(handler), false);
    xhr.addEventListener("error", handler.failed.bind(handler), false);
    xhr.addEventListener("abort", handler.canceled.bind(handler), false);
    xhr.open("POST", target);
    xhr.onreadystatechange=function(){
//    	console.log('ready',xhr.readyState,xhr.responseText);
        if(xhr.readyState==4){ handler.responseText = xhr.responseText; }
    }
    xhr.send(fd);
    return xhr;
//	console.log('upload',xhr);
}







//DragLoad.uploadButton = function (el) { 
jQuery.fn.uploadButton = function(typ){ // form-upload
	if(!typ){typ = 'files';}
    this.each(function(){
        var el = $(this);
        if(el.hasClass('isUploadButton')){ return; }
        var uploadButton = el.addClass('isUploadButton');
        var fileInput = $('<input type="file" style="display:none;"/>');
        if(typ=='files'){ 
        	fileInput.attr('multiple',1); 
        } else {
        	fileInput.attr('directory',1).attr('webkitdirectory',1); 
        }
        uploadButton.append(fileInput);//.append(folderInput).append(folderButton);
        uploadButton.click(function(evt){ 
            if($(evt.target).attr('type')=='file'){return;}
    //    	console.log('input',fileInput);  
            fileInput.trigger('click');
            return false;
        });
        fileInput.on('change',DragLoad.uploadButtonGetFiles);
    });
}
//        var folderInput = $('<input type="file" directory="1" webkitdirectory="1" style="display:none;"/>');
//        var folderButton = $('<span class="folder"/>').html('&#x21c8;');
//        folderButton.click(function(evt){ 
//            if($(evt.target).attr('type')=='file'){return;}
//    //    	console.log('input',folderInput);   
//            folderInput.trigger('click');
//            return false;
//        });
//        folderInput.on('change',DragLoad.uploadButtonGetFiles);



DragLoad.uploadButtonGetFiles = function(evt){
    var files = evt.target.files; // FileList object
	var target = $(evt.target).parent();
//    console.log('files',files,files[0]);
//    for (var i=0; i<files.length; i++) {
//    	files[i].sizeString = FileScanner.getSizeString(files[i]);
//    }
//	console.log('upload to',target[0]);
    if(target.attr('onFileDrop')){ 
        eval(target.attr('onFileDrop'))(files, target); 
    }
    new FileListHandle(files, target);
//    new FileScanner({items:files});
}




DragLoad.getImage = function(file){
    var imageType = /image.*/;
     
    if (!file.type.match(imageType)) { return; }
    
    var img = document.createElement("img");
//    img.classList.add("obj");
//    img.file = file;
//    preview.appendChild(img);
     
    var reader = new FileReader();
    reader.onload = (function(aImg) { return function(e) { aImg.src = e.target.result; }; })(img);
    reader.readAsDataURL(file);
	return $(img);
}






// jQuery convenience funtion
jQuery.fn.draggable = function(){
    this.each(function(){
        var el = $(this);
        if(el.hasClass('isDraggable')){ return 1; }
        el.addClass('isDraggable');
//        var uid = Math.random()*10000000000000000000;
        el.attr('draggable','true');//.attr('uid',uid);
//        el.attr('ondragstart','DragLoad.start(event)').attr('ondragend','DragLoad.stop(event);');
        el.bind('dragstart', DragLoad.start).bind('dragend',DragLoad.stop)
    });
    return this;
};


// jQuery convenience funtion
jQuery.fn.dropTarget = function(){
    this.each(function(){
        var el = $(this);
        if(el.hasClass('isDropTarget')){ return 1; }
        el.addClass('isDropTarget');
//        el.attr('onDrop','DragLoad.drop(event)').attr('onDragOver','DragLoad.over(event)');
//        el.attr('onDragEnter','DragLoad.enter(event)').attr('onDragLeave','DragLoad.leave(event)');
		el.bind('drop',DragLoad.drop).bind('dragover',DragLoad.over);
		el.bind('dragleave',DragLoad.leave).bind('dragenter',DragLoad.enter);
//        console.log(el[0],'isDropTarget');
    });
    return this;
};





// Drag OUT

//application/pdf:HTML5CheatSheet.pdf:http://thecssninja.come/demo/gmail_dragout/html5-cheat-sheet.pdf
DragLoad.contentTypes = {pdf:'application/pdf', png:'image/png'}; 
jQuery.fn.dragOut = function(){ 
    this.each(function(){
        var el = $(this);
        if(el.hasClass('canDragOut')){ return 1; }
        el.addClass('canDragOut');
//    	console.log('dragOut',el[0]);
        var url = el.attr('downloadSource');
        if(url.slice(0,7)!='http://'){ url = document.URL.split('/').slice(0,-1).join('/')+'/'+url;}
        //'http://'+document.domain+'/'+url; }
        console.log('source',url);
        var fileName = url.split('/').slice(-1)[0];
        var extension = fileName.split('.').slice(-1)[0].toLowerCase();
        var contentType = DragLoad.contentTypes[extension];
//        console.log('dO',fileName,'ext',extension,'ct',contentType);
        var downloadUrl = contentType +':'+ fileName +':'+ url;
//        console.log('dl',downloadUrl);
        el.draggable();
//        el.attr('draggable','true');
        el[0].addEventListener("dragstart",function(evt){
            evt.dataTransfer.setData("DownloadURL",downloadUrl);
        },false);
        
    });
    return this;
};






// automatically enable all new inserted DOM-nodes with .draggable / .dropTarget
$(document).bind("DOMNodeInserted",function(ev){
    $('.draggable').not('.isDraggable').each(function(i,el){
        $(el).draggable();
    });
    $('[uploadTarget]').not('.isDropTarget').each(function(i,el){
        $(el).dropTarget();
    });
    $('[onDomDrop]').not('.isDropTarget').each(function(i,el){
        $(el).dropTarget();
    });
    $('[onFileDrop]').not('.isDropTarget').each(function(i,el){
        $(el).dropTarget();
    });
    $('.fileUploadButton').not('.hasInput').each(function(i,el){
        $(el).uploadButton('files');
    });
    $('.uploadButton').not('.hasInput').each(function(i,el){
        $(el).uploadButton('files');
    });
    $('.folderUploadButton').not('.hasInput').each(function(i,el){
        $(el).uploadButton('folder');
    });
    $('[downloadSource]').not('.canDragOut').each(function(i,el){
        $(el).dragOut();
    });
});



//String.prototype.startsWith = function(substring) {
//  var str = this+'';
//  return (str.substr(0,substring.length)==substring);
//};




